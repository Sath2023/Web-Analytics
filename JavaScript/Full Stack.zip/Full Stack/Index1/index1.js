function thankyou()
{
    alert("Nin net sari illa noodu");
}