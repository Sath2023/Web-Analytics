let button = document.getElementById('click')
button.addEventListener('click',()=>{
    alert("Anna nim abhimani")
})