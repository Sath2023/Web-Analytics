$('document').ready(function()
{
    $('button#hideBtn').click(()=>$('p#one').hide)
})